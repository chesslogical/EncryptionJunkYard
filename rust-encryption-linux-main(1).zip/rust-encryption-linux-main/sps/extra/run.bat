sps test.txt

pause
