note- this repo does NOT do version contol - i just overwrite the app directly. ALL the apps are on deck for constant updates. They all work but are no where near being done. 


# encryption apps for linux. 

This repo is new, it will take a while to put more apps here, test them, and have both chatgpt and grok audit them and make them better. 


Keymaker- make a key from one byte to 20GB 

xcha - VERY minimal, high secuurity encryption app + keygen

xcha1 - VERY VERY minimal, high security encryption password only

xor - from weak security to strongest possible- all in one app

rage-helper - an awesome bash script to make rage app WAY easier to use 

tf- threefish1024 

ser - serpent256 algo
